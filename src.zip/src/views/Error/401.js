import React from 'react';

const Error401 = () => {
    return (
        <div>
            <p> 401 Error </p>
        </div>

    )

}

export default Error401;