import React from 'react';

const Error404 = () => {
    return (
        <div>
            <p> 404 Error </p>
        </div>

    )

}

export default Error404;